# Study Squad — ready-made frontend demo

A mobile-first React + Tailwind prototype for Study Squad. It includes a clickable dashboard, Pomodoro timer, squad status, invite-code demo, challenge progress, leaderboard, chat, reactions, nudges, profile editing and confetti.

## 1. Run it locally

Install Node.js 20 or newer. In this folder, run:

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually http://localhost:5173).

## 2. Supabase database

1. Create a project at https://supabase.com.
2. Open **SQL Editor** in the Supabase dashboard.
3. Paste and run `supabase/schema.sql`.
4. Copy your Project URL and anon/public key from **Project Settings → API**.
5. Copy `.env.example` to `.env` and fill in the values.

The current interface intentionally runs in **demo mode** with sample data. The Supabase client is prepared, but authentication and live database writes are not connected yet. We will connect them in the next build step.

## 3. Deploy to Vercel

1. Push this folder to a GitHub repository.
2. Import the repository in https://vercel.com.
3. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Vercel Environment Variables.
4. Deploy.

## Important production notes

- Demo profile, chat, points, squad members and challenge changes are not persisted.
- The demo timer awards points only when its countdown reaches zero, but client-side timers are not secure anti-cheat. Production completion and point awards must be validated by a Supabase database function using server timestamps.
- Before public launch, add row-level security policies, server-side squad capacity enforcement (max 6), invite-code expiry/rate limits, moderation/reporting, and proper weekly challenge aggregation.
- Never put a Supabase service-role key in frontend code.

## 4. Build an Android APK with GitHub Actions
See `GITHUB-APK-GUIDE.md`. This project includes a GitHub Actions workflow that builds a test/debug APK and uploads it as a downloadable artifact.
