# Build and download the Study Squad APK (beginner guide)

This repository is configured to build an Android **debug APK** using GitHub Actions.

## 1. Upload the project to GitHub
1. Sign in at https://github.com.
2. Create a new repository named `study-squad` (Public or Private is fine).
3. Upload the contents of this folder to the repository's `main` branch. Upload the files and folders inside this ZIP, not the ZIP itself.
4. Make sure `.github/workflows/build-android-apk.yml` is included. If GitHub's web uploader hides dot-folders, use GitHub Desktop or the browser's Add file flow and ensure the workflow file is committed.

## 2. Start the APK build
1. Open your repository on GitHub.
2. Select **Actions**. If prompted, enable GitHub Actions.
3. Choose **Build Study Squad Android APK** from the workflow list.
4. Press **Run workflow**, keep branch `main`, then press the green **Run workflow** button.
5. Wait for the run to finish with a green check mark.

A push to `main` also starts the workflow automatically.

## 3. Download and install
1. Open the completed workflow run.
2. Scroll to **Artifacts** at the bottom.
3. Download `study-squad-debug-apk` and extract the downloaded ZIP.
4. On your Android phone, open `app-debug.apk` and approve **Install unknown apps** for the browser or file manager if Android asks.

## Important
- This produces a debug APK for testing, not a signed Play Store release.
- The current app is still a frontend demo. Authentication, live chat, persistent squads, secure point validation and production Supabase policies are not finished. Do not launch it publicly or collect real user data yet.
- No Supabase secrets are needed to build this demo APK.
