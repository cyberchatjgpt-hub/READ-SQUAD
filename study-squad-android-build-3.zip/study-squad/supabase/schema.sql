-- Study Squad database schema (run in Supabase SQL Editor)
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  school text not null,
  total_points integer not null default 0 check (total_points >= 0),
  current_streak integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.squads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  invite_code text unique not null default upper(substr(encode(gen_random_bytes(8),'hex'),1,8)),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.squad_members (
  squad_id uuid not null references public.squads(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  joined_at timestamptz not null default now(),
  primary key (squad_id,user_id)
);

create table public.focus_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  squad_id uuid references public.squads(id) on delete set null,
  started_at timestamptz not null,
  completed_at timestamptz,
  duration_seconds integer not null default 1500 check (duration_seconds between 60 and 7200),
  points_awarded integer not null default 0,
  status text not null default 'in_progress' check (status in ('in_progress','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table public.challenges (
  id uuid primary key default gen_random_uuid(),
  squad_id uuid not null references public.squads(id) on delete cascade,
  title text not null,
  description text,
  target_minutes integer not null check (target_minutes > 0),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  bonus_points integer not null default 0,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table public.challenge_progress (
  id uuid primary key default gen_random_uuid(),
  challenge_id uuid not null references public.challenges(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  minutes_completed integer not null default 0,
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(challenge_id,user_id)
);

create table public.badges (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  description text not null,
  icon text not null
);

create table public.user_badges (
  user_id uuid not null references public.profiles(id) on delete cascade,
  badge_id uuid not null references public.badges(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key(user_id,badge_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  squad_id uuid not null references public.squads(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table public.message_reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key(message_id,user_id,emoji)
);

create index focus_sessions_user_completed_idx on public.focus_sessions(user_id,completed_at);
create index focus_sessions_squad_completed_idx on public.focus_sessions(squad_id,completed_at);
create index messages_squad_created_idx on public.messages(squad_id,created_at desc);
create index challenge_progress_challenge_idx on public.challenge_progress(challenge_id);

-- RLS is enabled now; policies will be added in the authentication step.
alter table public.profiles enable row level security;
alter table public.squads enable row level security;
alter table public.squad_members enable row level security;
alter table public.focus_sessions enable row level security;
alter table public.challenges enable row level security;
alter table public.challenge_progress enable row level security;
alter table public.badges enable row level security;
alter table public.user_badges enable row level security;
alter table public.messages enable row level security;
alter table public.message_reactions enable row level security;

insert into public.badges(code,name,description,icon) values
('first_session','First Session','Complete your first focus session','🌱'),
('seven_day_streak','7-Day Streak','Study on seven consecutive days','🔥'),
('squad_mvp','Squad MVP','Earn the most points in your squad','🏆'),
('challenge_champion','Challenge Champion','Complete a squad challenge','👑')
on conflict (code) do nothing;
